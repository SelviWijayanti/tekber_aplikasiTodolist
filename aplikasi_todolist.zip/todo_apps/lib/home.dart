import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:todo_apps/db.dart';
import 'package:todo_apps/form.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final DbHelper dbHelper = DbHelper();
  late List<Note> notes;

  @override
  void initState() {
    super.initState();
    refreshNotes();
  }

  Future<void> refreshNotes() async {
    final fetchedNotes = await dbHelper.getNotes();
    setState(() {
      notes = fetchedNotes;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Aplikasi Todolist'),
      ),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TodoForm(
                    onSave: (note) async {
                      await dbHelper.insertNote(note);
                      await refreshNotes();
                    },
                  ),
                ),
              );
            },
            child: Text('Tambah Kegiatan'),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: notes.length,
              itemBuilder: (context, index) {
                final note = notes[index];
                return ListTile(
                  title: Text(note.title),
                  subtitle: Text(note.date),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TodoForm(
                                note: note,
                                onSave: (updatedNote) async {
                                  final newNote = Note(
                                    id: note
                                        .id, // Menggunakan id yang sama dengan note yang sedang diedit
                                    title: updatedNote.title,
                                    content: updatedNote.content,
                                    date: updatedNote.date,
                                  );
                                  await dbHelper.updateNote(newNote);
                                  await refreshNotes();
                                },
                              ),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () async {
                          await dbHelper.deleteNote(
                              note.id!); // Menghapus catatan dari database
                          await refreshNotes(); // Menjalankan fungsi refresh untuk memperbarui tampilan
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
